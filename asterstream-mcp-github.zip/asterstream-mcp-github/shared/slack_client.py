"""
shared/slack_client.py — Slack Notification Client
===================================================
Sends structured alerts and reports to Slack channels.

Setup:
  1. Go to https://api.slack.com/apps → Create App
  2. Enable Incoming Webhooks
  3. Add webhook URL to .env as SLACK_WEBHOOK_URL

Security:
  - Webhook URL loaded from env only — never exposed to AI tools
  - Company name shown; tenant_id (registration number) NOT included in Slack messages
"""
import os, logging
from typing import Optional
import httpx
from dotenv import load_dotenv

load_dotenv()
log = logging.getLogger("ast.slack")

class SlackClient:
    def __init__(self, company: str = ""):
        self._url     = os.getenv("SLACK_WEBHOOK_URL", "")
        self._company = company
        if not self._url:
            log.warning("[Slack] SLACK_WEBHOOK_URL not set — notifications disabled")

    async def _send(self, payload: dict) -> bool:
        if not self._url:
            log.info("[Slack] (disabled) %s", str(payload)[:120])
            return False
        try:
            async with httpx.AsyncClient(timeout=10) as c:
                r = await c.post(self._url, json=payload)
                ok = r.text == "ok"
                if not ok:
                    log.error("[Slack] Failed: %s", r.text)
                return ok
        except Exception as e:
            log.error("[Slack] Error: %s", e)
            return False

    async def energy_alert(self, device: str, deviation_pct: float,
                           kw: float, action: str) -> bool:
        em = "🔴" if deviation_pct > 40 else "🟡"
        return await self._send({"blocks": [
            {"type": "header",
             "text": {"type": "plain_text", "text": f"{em} Energy Alert — {self._company}"}},
            {"type": "section", "fields": [
                {"type": "mrkdwn", "text": f"*Device:*\n{device}"},
                {"type": "mrkdwn", "text": f"*Deviation:*\n+{deviation_pct:.1f}% above baseline"},
                {"type": "mrkdwn", "text": f"*Load:*\n{kw:.1f} kW"},
                {"type": "mrkdwn", "text": f"*Action:*\n{action}"},
            ]},
            {"type": "context", "elements": [
                {"type": "mrkdwn", "text": "🤖 AsterStream AI · asterstreambuild.com"}]},
        ]})

    async def esg_report(self, period: str, tco2e: float,
                         score: int, currency: str, cost: float) -> bool:
        em = "✅" if score >= 80 else ("⚠️" if score >= 50 else "❌")
        return await self._send({"blocks": [
            {"type": "header",
             "text": {"type": "plain_text",
                      "text": f"📊 ESG Monthly Report — {self._company} · {period}"}},
            {"type": "section", "fields": [
                {"type": "mrkdwn", "text": f"*Total Emissions:*\n{tco2e:.3f} tCO₂e"},
                {"type": "mrkdwn", "text": f"*Compliance Score:*\n{em} {score}/100"},
                {"type": "mrkdwn", "text": f"*Energy Cost:*\n{currency} {cost:,.2f}"},
            ]},
            {"type": "actions", "elements": [
                {"type": "button",
                 "text": {"type": "plain_text", "text": "View ESG Dashboard"},
                 "url": "https://asterstreambuild.com/EsgCompliance"},
            ]},
        ]})

    async def device_offline(self, device: str, site: str, hours: float) -> bool:
        return await self._send({"blocks": [
            {"type": "header",
             "text": {"type": "plain_text", "text": f"🔌 Device Offline — {self._company}"}},
            {"type": "section", "fields": [
                {"type": "mrkdwn", "text": f"*Device:*\n{device}"},
                {"type": "mrkdwn", "text": f"*Site:*\n{site}"},
                {"type": "mrkdwn", "text": f"*Offline:*\n{hours:.1f} hours"},
            ]},
        ]})

    async def power_alert(self, alert_type: str, severity: str,
                          value: float, unit: str, location: str) -> bool:
        em = {"critical": "🔴", "warning": "🟡", "info": "🔵"}.get(severity, "⚪")
        return await self._send({"blocks": [
            {"type": "header",
             "text": {"type": "plain_text",
                      "text": f"{em} Power Alert [{severity.upper()}] — {self._company}"}},
            {"type": "section", "fields": [
                {"type": "mrkdwn", "text": f"*Type:*\n{alert_type}"},
                {"type": "mrkdwn", "text": f"*Value:*\n{value:.2f} {unit}"},
                {"type": "mrkdwn", "text": f"*Location:*\n{location}"},
            ]},
        ]})

    async def text(self, msg: str) -> bool:
        return await self._send({"text": f"[{self._company}] {msg}"})

    async def api_quota_warning(self, usage_pct: float, plan: str) -> bool:
        em = "🔴" if usage_pct >= 90 else "🟡"
        return await self._send({"blocks": [
            {"type": "header",
             "text": {"type": "plain_text",
                      "text": f"{em} API Quota Warning — {self._company}"}},
            {"type": "section", "fields": [
                {"type": "mrkdwn", "text": f"*Usage:*\n{usage_pct:.1f}% of monthly limit"},
                {"type": "mrkdwn", "text": f"*Plan:*\n{plan}"},
            ]},
            {"type": "context", "elements": [
                {"type": "mrkdwn",
                 "text": "Upgrade at asterstreamtech.com/Billing"}]},
        ]})
