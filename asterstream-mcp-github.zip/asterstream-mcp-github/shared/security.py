"""
shared/security.py — AsterStream MCP Security Core v4
=======================================================
Security Layers:
  [1] TenantId frozen at startup from env vars — AI cannot modify
  [2] X-Tenant-Id header + query param + POST body injection
  [3] AI-supplied tenant_id arguments scrubbed and replaced
  [4] Prompt injection pattern detection and blocking
  [5] Rate limiting: max 20 calls/min per tool
  [6] Write confirmation: destructive tools require confirmed=true
  [7] API token masking in all logs
  [8] *** SUBSCRIPTION VALIDATION ***
      Before EVERY tool call, the MCP server calls the portal API
      to verify the customer's subscription is active.
      If trial has expired or payment failed, the tool is BLOCKED.
"""
import os, time, logging, hashlib
from dataclasses import dataclass
from collections import defaultdict
from typing import Optional
import httpx
from dotenv import load_dotenv

load_dotenv()
log = logging.getLogger("ast.security")

# ── Portal validation endpoint ────────────────────────────────────
PORTAL_VALIDATE_URL = os.getenv(
    "PORTAL_VALIDATE_URL",
    "https://mcp.asterstreamtech.com/api/mcp/validate"
)


# ── [1] Immutable Tenant Identity ────────────────────────────────
@dataclass(frozen=True)
class TenantIdentity:
    tenant_id:    str
    api_token:    str
    api_base:     str
    company_name: str = ""
    country_code: str = "SG"
    plan:         str = "professional"

    def __post_init__(self):
        if not self.tenant_id.strip():
            raise ValueError("ASTERSTREAM_TENANT_ID is not set — check .env")
        if len(self.api_token) < 8:
            raise ValueError("ASTERSTREAM_API_TOKEN is too short — check .env")
        masked = self.api_token[:6] + "***" + self.api_token[-3:]
        log.info("[Auth] Bound → tenant=%s company='%s' token=%s",
                 self.tenant_id, self.company_name or "N/A", masked)


def load_ems_identity() -> TenantIdentity:
    return TenantIdentity(
        tenant_id    = os.environ["ASTERSTREAM_TENANT_ID"],
        api_token    = os.environ["ASTERSTREAM_API_TOKEN"],
        api_base     = os.getenv("ASTERSTREAM_API_BASE", "https://asterstreambuild.com"),
        company_name = os.getenv("TENANT_COMPANY_NAME", ""),
        country_code = os.getenv("TENANT_COUNTRY_CODE", "SG"),
        plan         = os.getenv("TENANT_PLAN", "professional"),
    )


def load_portal_identity() -> TenantIdentity:
    return TenantIdentity(
        tenant_id    = os.environ["PORTAL_TENANT_ID"],
        api_token    = os.environ["PORTAL_API_TOKEN"],
        api_base     = os.getenv("PORTAL_API_BASE", "https://asterstreamtech.com"),
        company_name = os.getenv("PORTAL_COMPANY_NAME", ""),
        country_code = os.getenv("TENANT_COUNTRY_CODE", "SG"),
        plan         = os.getenv("PORTAL_PLAN", "standard"),
    )


# ── [8] Subscription Validator ────────────────────────────────────
class SubscriptionValidator:
    """
    Validates the customer's subscription before every tool call.
    Calls the portal's /api/mcp/validate endpoint.

    Result is cached for 5 minutes per API key to avoid
    hammering the portal on every single tool call.
    """
    # TTL read from env; default 300s (matches PlanConstants.ValidationCacheSecs)
    _CACHE_TTL = int(os.getenv("VALIDATION_CACHE_SECS", "300"))  # 5 minutes

    def __init__(self, api_token: str):
        self._token = api_token
        self._cache: dict[str, tuple[bool, str, float]] = {}  # token → (allowed, msg, expires)

    async def check(self, tool_name: str, server_type: str) -> tuple[bool, str]:
        """Returns (allowed, error_message)."""
        now = time.time()
        cached = self._cache.get(self._token)
        if cached:
            allowed, msg, expires = cached
            if now < expires:
                return allowed, msg

        try:
            async with httpx.AsyncClient(timeout=8) as c:
                r = await c.post(PORTAL_VALIDATE_URL, json={
                    "ApiKey": self._token,
                    "Tool":   tool_name,
                    "Server": server_type,
                })

            if r.status_code == 200:
                data = r.json()
                if data.get("allowed"):
                    remaining = data.get("remaining_calls", -1)
                    self._cache[self._token] = (True, "", now + self._CACHE_TTL)
                    log.debug("[Sub] Allowed: tool=%s remaining=%s", tool_name, remaining)
                    return True, ""
                else:
                    msg = data.get("message", "Subscription not active.")
                    # Don't cache failures — recheck every call
                    self._cache.pop(self._token, None)
                    log.warning("[Sub] Blocked: tool=%s reason=%s", tool_name, data.get("reason"))
                    return False, msg
            else:
                data = r.json() if r.content else {}
                msg = data.get("message", f"Subscription check failed (HTTP {r.status_code}).")
                self._cache.pop(self._token, None)
                return False, msg

        except httpx.TimeoutException:
            # On timeout, allow (fail open) to avoid blocking legitimate customers
            log.error("[Sub] Validation timeout for tool=%s — allowing (fail open)", tool_name)
            self._cache[self._token] = (True, "", now + 60)  # cache for 1 min
            return True, ""
        except Exception as e:
            log.error("[Sub] Validation error: %s — allowing (fail open)", e)
            return True, ""  # fail open on network errors


# ── [4] Prompt Injection Detection ────────────────────────────────
_INJECTIONS = [
    "ignore previous instructions", "disregard your", "forget your rules",
    "you are now", "act as", "jailbreak", "prompt injection",
    "reveal your system prompt", "show me your instructions",
    "bypass", "override tenant", "switch tenant",
    "access all tenants", "list all companies", "dump all data",
]

def check_injection(text: str) -> Optional[str]:
    low = text.lower()
    for p in _INJECTIONS:
        if p in low:
            return p
    return None


# ── [5] Rate Limiter ──────────────────────────────────────────────
class RateLimiter:
    def __init__(self, max_per_min: int = 20):
        self._max = max_per_min
        self._log: dict[str, list[float]] = defaultdict(list)

    def check(self, tool: str) -> bool:
        now  = time.time()
        hits = [t for t in self._log[tool] if now - t < 60]
        self._log[tool] = hits
        if len(hits) >= self._max:
            log.warning("[RateLimit] tool=%s  %d/%d/min", tool, len(hits), self._max)
            return False
        self._log[tool].append(now)
        return True


# ── [6] Write-op tools require confirmed=true ─────────────────────
WRITE_TOOLS = {
    "shutdown_idle_equipment", "set_device_setpoint", "approve_ai_recommendation",
    "resolve_compliance_issue", "revoke_api_key", "create_api_key",
    "set_zone_hvac", "schedule_device", "add_activity_data",
}

# ── [2][3] Blocked argument keys ─────────────────────────────────
_BLOCKED_KEYS = {"tenant_id", "tenantId", "TenantId", "tenant", "TENANT_ID", "api_token"}


# ── Secure HTTP Client ────────────────────────────────────────────
class SecureClient:
    """
    All HTTP calls carry three layers of TenantId.
    AI-supplied tenant_id fields are stripped and replaced.
    """
    def __init__(self, identity: TenantIdentity,
                 rl: Optional[RateLimiter] = None,
                 validator: Optional[SubscriptionValidator] = None):
        self._id   = identity
        self._rl   = rl or RateLimiter()
        self._val  = validator
        self._hdrs = {
            "Authorization": f"Bearer {identity.api_token}",
            "X-Tenant-Id":   identity.tenant_id,
            "Content-Type":  "application/json",
            "User-Agent":    "AsterStream-MCP/4.0",
        }

    def _clean(self, d: dict) -> dict:
        return {k: v for k, v in d.items()
                if k not in _BLOCKED_KEYS and k != "confirmed"}

    def _rl_check(self, tool: str):
        if tool and not self._rl.check(tool):
            raise PermissionError(f"Rate limit exceeded for '{tool}' (max 20/min)")

    async def get(self, path: str, params: dict = {}, tool: str = "") -> dict:
        self._rl_check(tool)
        p = self._clean(params)
        p["tenant_id"] = self._id.tenant_id
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.get(f"{self._id.api_base}{path}", headers=self._hdrs, params=p)
            self._guard(r)
            return r.json()

    async def post(self, path: str, body: dict = {}, tool: str = "") -> dict:
        self._rl_check(tool)
        b = self._clean(body)
        b["tenant_id"] = self._id.tenant_id
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.post(f"{self._id.api_base}{path}", headers=self._hdrs, json=b)
            self._guard(r)
            return r.json()

    def _guard(self, r: httpx.Response):
        if r.status_code == 403:
            raise PermissionError("Access denied — tenant mismatch")
        if r.status_code == 401:
            raise PermissionError("Unauthorized — token invalid or expired")
        r.raise_for_status()

    def ctx(self) -> dict:
        return {
            "tenant_id": self._id.tenant_id,
            "company":   self._id.company_name or "N/A",
            "country":   self._id.country_code,
            "plan":      self._id.plan,
            "_note":     "All data is scoped exclusively to this tenant.",
        }


# ── Master tool guard (call before every tool execution) ─────────
async def tool_guard(
    tool_name:  str,
    arguments:  dict,
    validator:  Optional[SubscriptionValidator] = None,
    server_type: str = "ems",
) -> Optional[dict]:
    """
    Run ALL security checks. Return error dict if blocked, None if OK.

    Order:
      1. Prompt injection check
      2. Write confirmation check
      3. Subscription validation (blocks unpaid/expired customers)
      4. (Rate limiting is handled by SecureClient)
    """
    # [4] Prompt injection
    for v in arguments.values():
        if isinstance(v, str):
            hit = check_injection(v)
            if hit:
                log.warning("[Security] Injection blocked: tool=%s pattern='%s'", tool_name, hit)
                return {
                    "error":   "Blocked: potential prompt injection detected",
                    "pattern": hit,
                    "tool":    tool_name,
                }

    # [6] Write confirmation
    if tool_name in WRITE_TOOLS and not arguments.get("confirmed", False):
        return {
            "requires_confirmation": True,
            "tool":    tool_name,
            "message": (f"'{tool_name}' modifies system state. "
                        "Add confirmed=true to proceed."),
        }

    # [8] Subscription validation
    if validator:
        allowed, msg = await validator.check(tool_name, server_type)
        if not allowed:
            return {
                "error":       "Subscription required",
                "message":     msg,
                "upgrade_url": "https://mcp.asterstreamtech.com/#pricing",
                "tool":        tool_name,
            }

    return None  # all checks passed
