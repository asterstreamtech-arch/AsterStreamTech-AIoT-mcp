# Changelog

All notable changes to AsterStream MCP are documented in this file.

## [1.0.0] — 2026-05-28

### Initial Release

#### Added
- **EMS MCP Server** — 11 tools, 5 resources, 4 prompts for energy management
- **ESG MCP Server** — 10 tools, 5 resources, 4 prompts for carbon & compliance
- **Building MCP Server** — 11 tools, 4 resources, 4 prompts for smart building AIOps
- **Portal MCP Server** — 10 tools, 5 resources, 4 prompts for subscription management
- **9-layer security architecture** — TenantId binding, prompt injection detection, rate limiting
- **Subscription validation** — per-call API key and quota verification
- **Multi-country support** — SG, TW, MY, IN, ID, TH, VN, PH with localised emission factors
- **Write confirmation** — all destructive operations require `confirmed=true`
- **Slack integration** — optional notifications for anomalies, alerts, and ESG reports
- **AI forecasting** — Prophet + XGBoost models for energy prediction
- **AI anomaly detection** — Isolation Forest for device baseline deviation
