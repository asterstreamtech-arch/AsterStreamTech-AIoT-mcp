# AsterStream MCP — Security Architecture

## Overview

AsterStream MCP is designed for enterprise multi-tenant deployments where data isolation is critical. **Cross-tenant data access is structurally impossible** — not just enforced by policy.

Each MCP server process is bound to exactly one `TenantId` at startup. This binding is immutable for the lifetime of the process.

---

## Nine Security Layers

### Layer 1 — TenantId Binding at Startup

```python
@dataclass(frozen=True)
class TenantIdentity:
    tenant_id:    str
    api_token:    str
    api_base:     str
    company_name: str = ""
    country_code: str = "SG"
    plan:         str = "professional"
```

The `frozen=True` parameter makes the dataclass immutable after creation. No code path — including AI-generated tool arguments — can modify `tenant_id` after startup.

### Layer 2 — X-Tenant-Id Header

Every HTTP request to the AsterStream API includes:

```
X-Tenant-Id: 202512345A
Authorization: Bearer ast_live_xxx
```

The server rejects requests where the header doesn't match the authenticated customer.

### Layer 3 — Query Parameter Injection

Every GET request appends `?tenant_id=202512345A` to the URL. The API server performs a second validation against this parameter.

### Layer 4 — POST Body Injection

Every POST request includes `{"tenant_id": "202512345A"}` in the request body. The API server validates the body tenant against the authenticated session.

### Layer 5 — Argument Scrubbing

```python
_BLOCKED_KEYS = {"tenant_id", "tenantId", "TenantId", "tenant", "TENANT_ID", "api_token"}

def _clean(self, d: dict) -> dict:
    return {k: v for k, v in d.items()
            if k not in _BLOCKED_KEYS and k != "confirmed"}
```

If an AI agent attempts to supply a different `tenant_id` in tool arguments, the value is silently removed and the correct tenant ID is injected instead.

### Layer 6 — Prompt Injection Detection

The following patterns are detected and blocked before any tool executes:

```python
INJECTIONS = [
    "ignore previous instructions",
    "disregard your",
    "forget your rules",
    "you are now",
    "act as",
    "jailbreak",
    "prompt injection",
    "reveal your system prompt",
    "show me your instructions",
    "bypass",
    "override tenant",
    "switch tenant",
    "access all tenants",
    "list all companies",
    "dump all data",
    ...
]
```

If any argument value contains a blocked pattern, the tool call is rejected and a security warning is logged.

### Layer 7 — Rate Limiting

```python
class RateLimiter:
    def __init__(self, max_per_min: int = 20):
        ...
```

Maximum 20 tool calls per minute per MCP server process. Prevents abuse and runaway AI agent loops.

### Layer 8 — Write Confirmation

```python
WRITE_TOOLS = {
    "shutdown_idle_equipment",
    "set_device_setpoint",
    "approve_ai_recommendation",
    "set_zone_hvac",
    "schedule_device",
    "add_activity_data",
    "create_api_key",
    "revoke_api_key",
}
```

All write-operation tools require `confirmed=true` in the tool arguments:

```
Without confirmed=true:
{
  "requires_confirmation": true,
  "tool": "shutdown_idle_equipment",
  "message": "shutdown_idle_equipment modifies system state. Add confirmed=true to proceed."
}
```

This prevents AI agents from accidentally executing destructive operations.

### Layer 9 — Token Masking in Logs

```python
masked = self.api_token[:6] + "***" + self.api_token[-3:]
log.info("[Auth] Bound → token=%s", masked)
# Output: [Auth] Bound → token=ast_li***QCE
```

Full API tokens never appear in log files.

---

## Subscription Validation

Before every tool call, the Python MCP server calls the portal validation endpoint:

```
POST https://mcp.asterstreamtech.com/api/mcp/validate
{
  "ApiKey": "ast_live_xxx",
  "Tool":   "detect_energy_anomaly",
  "Server": "ems"
}
```

The portal checks:
1. API key exists and is not revoked
2. Subscription is active (not trial_expired, past_due, or cancelled)
3. Site quota not exceeded
4. Device quota not exceeded
5. Monthly API call quota not exceeded

Results are cached for `VALIDATION_CACHE_SECS` seconds (default: 300) to minimize latency.

---

## Data Flow

```
AI Agent (Claude / Cursor / GPT-4)
         │
         ▼ tool call with arguments
Python MCP Server
  ├─ TenantId: frozen at startup
  ├─ Prompt injection: check all arg values
  ├─ Write confirmation: require confirmed=true
  ├─ Rate limit: max 20/min
  └─ Arg scrubbing: strip tenant_id from args
         │
         ▼ POST /api/mcp/validate
AsterStream Portal (mcp.asterstreamtech.com)
  ├─ API key: SHA-256 hash lookup
  ├─ Subscription: status check
  └─ Quota: sites, devices, API calls
         │
         ▼ HTTP request with headers
AsterStream Main API (asterstreambuild.com)
  ├─ Bearer token: verified
  ├─ X-Tenant-Id: verified
  └─ Row-level filtering: tenant isolation
         │
         ▼
PostgreSQL — all queries include WHERE tenant_id = ?
```

---

## API Key Storage

| Location | What is stored |
|----------|---------------|
| Portal database | SHA-256 hash of the full key |
| Dashboard UI | Key prefix only (e.g. `ast_live_AbCd•••`) |
| Your `.env` file | Full key (shown once at creation) |
| Application logs | Never — always masked |

Keys are generated using `secrets.token_bytes(24)` — cryptographically secure random.
