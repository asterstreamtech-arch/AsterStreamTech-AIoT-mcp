# AsterStream MCP — Full Tool Reference

## EMS Server Tools

### `get_tenant_info`
Returns the authenticated tenant's identity and subscription details.

**Parameters:** None

**Returns:**
```json
{
  "tenant_id": "202512345A",
  "company_name": "Acme Energy Pte. Ltd.",
  "country_code": "SG",
  "plan": "professional",
  "api_base": "https://asterstreambuild.com"
}
```

---

### `get_building_power_usage`
Retrieves energy consumption data for a site over a specified period.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `site_id` | integer | No | Site ID (omit for all sites) |
| `period` | string | No | `today`, `week`, `month`, `year` (default: `today`) |
| `year` | integer | No | Year (e.g. 2026) |
| `month` | integer | No | Month 1-12 |

**Returns:** kWh, kW peak demand, power factor, CO₂ (tCO₂e), cost (SGD/TWD/MYR etc.)

---

### `detect_energy_anomaly`
AI-powered anomaly detection using Isolation Forest model. Identifies devices consuming significantly above their historical baseline.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `site_id` | integer | No | Filter by site |
| `threshold_pct` | number | No | Anomaly threshold % above baseline (default: 20) |

**Returns:** List of anomalous devices with deviation percentage and recommended action.

---

### `get_energy_cost_analysis`
Detailed electricity bill breakdown including tariff components.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `year` | integer | Yes | Year |
| `month` | integer | Yes | Month 1-12 |
| `site_id` | integer | No | Filter by site |

**Returns:** Peak kWh, off-peak kWh, demand charge (kW), power factor penalty, total cost.

---

### `forecast_energy_usage`
AI forecast using Facebook Prophet + XGBoost ensemble model.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `days` | integer | Yes | Number of days to forecast (1-30) |
| `site_id` | integer | No | Filter by site |

**Returns:** Daily forecast with confidence intervals.

---

### `shutdown_idle_equipment`
⚠️ **Write operation** — shuts down idle equipment.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `device_ids` | array | Yes | List of device IDs to shut down |
| `reason` | string | No | Reason for shutdown |
| `confirmed` | boolean | **Yes** | Must be `true` to execute |

---

### `set_device_setpoint`
⚠️ **Write operation** — changes device setpoint value.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `device_id` | integer | Yes | Target device ID |
| `setpoint_type` | string | Yes | `temperature`, `power`, `flow` |
| `value` | number | Yes | New setpoint value |
| `confirmed` | boolean | **Yes** | Must be `true` to execute |

---

## ESG Server Tools

### `calculate_ghg_emissions`
Calculates Scope 1, 2, and 3 greenhouse gas emissions.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `start_date` | string | Yes | ISO date `YYYY-MM-DD` |
| `end_date` | string | Yes | ISO date `YYYY-MM-DD` |
| `scope` | string | No | `1`, `2`, `3`, or `all` (default: `all`) |

**Returns:** Emissions in tCO₂e by scope, with emission factor details.

---

### `export_gri_report`
Generates a GRI 305 Emissions disclosure.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `year` | integer | Yes | Reporting year |
| `format` | string | No | `json` or `summary` (default: `json`) |

**Returns:** GRI 305-1, 305-2, 305-3, 305-4, 305-5 disclosure data.

---

### `generate_esg_report`
⚠️ **Write operation** — generates and emails ISO 14064 report.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `year` | integer | Yes | Reporting year |
| `quarter` | integer | No | Quarter 1-4 (omit for annual) |
| `confirmed` | boolean | **Yes** | Must be `true` to send email |

---

## Building Server Tools

### `predict_device_failure`
AI failure prediction using Isolation Forest model trained on historical sensor data.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `site_id` | integer | No | Filter by site |
| `days_ahead` | integer | No | Prediction horizon in days (default: 7) |

**Returns:** Devices with failure probability score, predicted failure date, recommended action.

---

### `set_zone_hvac`
⚠️ **Write operation** — sets HVAC temperature and operating mode for a building zone.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `zone_id` | integer | Yes | Target zone ID |
| `temperature` | number | Yes | Target temperature in °C |
| `mode` | string | Yes | `cool`, `heat`, `fan`, `auto`, `off` |
| `confirmed` | boolean | **Yes** | Must be `true` to execute |

---

### `schedule_device`
⚠️ **Write operation** — sets automatic on/off schedule for a device.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `device_id` | integer | Yes | Target device ID |
| `on_time` | string | Yes | Daily on time `HH:MM` |
| `off_time` | string | Yes | Daily off time `HH:MM` |
| `days_of_week` | array | No | e.g. `["Mon","Tue","Wed","Thu","Fri"]` |
| `confirmed` | boolean | **Yes** | Must be `true` to execute |

---

## Portal Server Tools

### `get_my_subscription`
Returns current subscription status, plan details, and billing information.

**Parameters:** None

**Returns:** Plan name, status (active/trialing/past_due), trial end date, next invoice date, amount.

---

### `get_usage_forecast`
Predicts whether the monthly API quota will be exhausted before month end.

**Parameters:** None

**Returns:** Current usage, monthly limit, projected usage at month end, days until quota exhaustion.

---

### `revoke_api_key`
⚠️ **Write operation** — immediately revokes an API key.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `key_id` | integer | Yes | API key ID to revoke |
| `confirmed` | boolean | **Yes** | Must be `true` to revoke |
