"""
AsterStream API Portal MCP Server — asterstreamtech.com (Secure Multi-Tenant)
==============================================================================
Tools: 10  Resources: 5  Prompts: 4
Each tenant only sees their own subscription, API keys, and usage data.
"""
import asyncio, json, sys, os, logging
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from datetime import datetime
from shared.security import load_portal_identity, SecureClient, tool_guard
from shared.slack_client import SlackClient
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Resource, Tool, TextContent, Prompt, PromptMessage, GetPromptResult

logging.basicConfig(level=logging.INFO)
ID    = load_portal_identity()
C     = SecureClient(ID)
SLACK = SlackClient(ID.company_name)
server = Server("asterstream-portal")

@server.list_resources()
async def list_resources():
    t = ID.tenant_id
    return [
        Resource(uri=f"portal://{t}/subscription",
                 name="My Subscription",
                 description="Current plan, billing status, trial info",
                 mimeType="application/json"),
        Resource(uri=f"portal://{t}/apikeys",
                 name="My API Keys",
                 description="All API keys with usage stats",
                 mimeType="application/json"),
        Resource(uri=f"portal://{t}/usage/today",
                 name="Usage Today",
                 description="API call count and error rate today",
                 mimeType="application/json"),
        Resource(uri=f"portal://{t}/usage/month",
                 name="Usage This Month",
                 description="Monthly API usage by endpoint and key",
                 mimeType="application/json"),
        Resource(uri=f"portal://{t}/invoices",
                 name="Invoice History",
                 description="Past 12 months of invoices",
                 mimeType="application/json"),
    ]

@server.read_resource()
async def read_resource(uri: str) -> str:
    t = ID.tenant_id
    routes = {
        f"portal://{t}/subscription": ("/api/portal/my/subscription",{}),
        f"portal://{t}/apikeys":      ("/api/portal/my/apikeys",{}),
        f"portal://{t}/usage/today":  ("/api/portal/my/usage",{"period":"today"}),
        f"portal://{t}/usage/month":  ("/api/portal/my/usage",{"period":"month"}),
        f"portal://{t}/invoices":     ("/api/portal/my/invoices",{"limit":12}),
    }
    if uri not in routes:
        return json.dumps({"error":f"Unknown: {uri}"})
    path, params = routes[uri]
    try:
        return json.dumps({"tenant_id":t,"data":await C.get(path,params)},
                          ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"error":str(e)})

@server.list_tools()
async def list_tools():
    return [
        Tool(name="get_tenant_info",
             description="Return authenticated portal tenant identity and plan.",
             inputSchema={"type":"object","properties":{}}),
        Tool(name="get_my_usage_stats",
             description="My API usage: call count, error rate, top endpoints.",
             inputSchema={"type":"object","properties":{
                 "period":{"type":"string","enum":["today","week","month"],"default":"month"},
             }}),
        Tool(name="list_my_api_keys",
             description="List all my API keys with usage, status, and expiry.",
             inputSchema={"type":"object","properties":{}}),
        Tool(name="create_api_key",
             description="Create a new API key for my account. ⚠️ Requires confirmed=true.",
             inputSchema={"type":"object","required":["key_name","confirmed"],"properties":{
                 "key_name":     {"type":"string"},
                 "expires_days": {"type":"integer","description":"0 = no expiry"},
                 "confirmed":    {"type":"boolean"},
             }}),
        Tool(name="revoke_api_key",
             description="Revoke one of my API keys immediately. ⚠️ Requires confirmed=true.",
             inputSchema={"type":"object","required":["key_id","confirmed"],"properties":{
                 "key_id":    {"type":"string"},
                 "reason":    {"type":"string"},
                 "confirmed": {"type":"boolean"},
             }}),
        Tool(name="get_my_subscription",
             description="My subscription plan, billing cycle, trial status, next invoice.",
             inputSchema={"type":"object","properties":{}}),
        Tool(name="get_api_error_analysis",
             description="Analyse my API errors: types, frequency, affected endpoints.",
             inputSchema={"type":"object","properties":{
                 "period":{"type":"string","default":"week"},
             }}),
        Tool(name="get_my_invoices",
             description="My invoice history with amounts and PDF links.",
             inputSchema={"type":"object","properties":{
                 "limit":{"type":"integer","default":12},
             }}),
        Tool(name="get_usage_forecast",
             description="Forecast whether I will exceed my monthly API quota.",
             inputSchema={"type":"object","properties":{}}),
        Tool(name="send_quota_warning_slack",
             description="Send a quota usage warning to the Slack channel.",
             inputSchema={"type":"object","required":["usage_pct","plan"],"properties":{
                 "usage_pct":{"type":"number","description":"Current usage % of monthly limit"},
                 "plan":     {"type":"string"},
             }}),
    ]

@server.call_tool()
async def call_tool(name: str, arguments: dict):
    guard = tool_guard(name, arguments)
    if guard:
        return [TextContent(type="text", text=json.dumps(guard))]
    try:
        if name == "get_tenant_info":
            result = C.ctx()
        elif name == "get_my_usage_stats":
            result = await C.get("/api/portal/my/usage", arguments, tool=name)
        elif name == "list_my_api_keys":
            result = await C.get("/api/portal/my/apikeys", tool=name)
        elif name == "create_api_key":
            result = await C.post("/api/portal/my/apikeys", arguments, tool=name)
        elif name == "revoke_api_key":
            result = await C.post(
                f"/api/portal/my/apikeys/{arguments['key_id']}/revoke",
                {"reason":arguments.get("reason","revoked via MCP")}, tool=name)
        elif name == "get_my_subscription":
            result = await C.get("/api/portal/my/subscription", tool=name)
        elif name == "get_api_error_analysis":
            result = await C.get("/api/portal/my/errors", arguments, tool=name)
        elif name == "get_my_invoices":
            result = await C.get("/api/portal/my/invoices", arguments, tool=name)
        elif name == "get_usage_forecast":
            result = await C.get("/api/portal/my/usage/forecast", tool=name)
        elif name == "send_quota_warning_slack":
            ok = await SLACK.api_quota_warning(
                arguments["usage_pct"], arguments["plan"])
            result = {"slack_sent": ok}
        else:
            result = {"error": f"Unknown tool: {name}"}
        return [TextContent(type="text",
                            text=json.dumps(result, ensure_ascii=False, indent=2))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({"error":str(e)}))]

@server.list_prompts()
async def list_prompts():
    return [
        Prompt(name="monthly_usage_review",
               description="Review monthly API usage, quota, and forecast"),
        Prompt(name="api_error_diagnosis",
               description="Diagnose API errors and identify root causes"),
        Prompt(name="api_key_security_audit",
               description="Audit API keys — find idle, suspicious, or expiring keys"),
        Prompt(name="subscription_review",
               description="Review subscription plan fit and upgrade recommendations"),
    ]

@server.get_prompt()
async def get_prompt(name: str, arguments=None):
    co = ID.company_name or ID.tenant_id
    now = datetime.utcnow()
    tpl = {
        "monthly_usage_review": (
            f"Review {now.strftime('%B %Y')} API usage for {co} ({ID.tenant_id}). "
            "Call get_my_usage_stats (period=month) and get_usage_forecast. "
            "If usage >80%, call send_quota_warning_slack. "
            "Report: total calls, error rate, quota %, top endpoints, upgrade recommendation."
        ),
        "api_error_diagnosis": (
            f"Diagnose API errors for {co} ({ID.tenant_id}). "
            "Call get_api_error_analysis (period=week). "
            "Report: error type distribution, most-affected endpoints, "
            "error rate trend, and specific fixes."
        ),
        "api_key_security_audit": (
            f"Audit API keys for {co} ({ID.tenant_id}). "
            "Call list_my_api_keys. "
            "Flag: keys unused for 30+ days (revoke candidate), "
            "keys with abnormally high usage (possible leak), "
            "keys expiring within 7 days."
        ),
        "subscription_review": (
            f"Review subscription for {co} ({ID.tenant_id}). "
            "Call get_my_subscription and get_my_usage_stats. "
            "Analyze: does current plan fit usage? "
            "ROI of upgrading to next tier? Annual billing discount opportunity?"
        ),
    }
    return GetPromptResult(
        description=name,
        messages=[PromptMessage(role="user",
                                content=TextContent(type="text",
                                                    text=tpl.get(name,f"Analyze portal data for {ID.tenant_id}.")))])

async def main():
    async with stdio_server() as (r, w):
        await server.run(r, w, server.create_initialization_options())

if __name__ == "__main__":
    asyncio.run(main())
