"""
AsterStream ESG MCP Server — Carbon & Compliance (Secure Multi-Tenant)
=======================================================================
Tools: 10  Resources: 5  Prompts: 4
"""
import asyncio, json, sys, os, logging
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from datetime import datetime
from shared.security import load_ems_identity, SecureClient, tool_guard
from shared.slack_client import SlackClient
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Resource, Tool, TextContent, Prompt, PromptMessage, GetPromptResult

logging.basicConfig(level=logging.INFO)
ID    = load_ems_identity()
C     = SecureClient(ID)
SLACK = SlackClient(ID.company_name)
server = Server("asterstream-esg")

@server.list_resources()
async def list_resources():
    t, yr = ID.tenant_id, datetime.utcnow().year
    return [
        Resource(uri=f"esg://{t}/inventory/{yr}",
                 name=f"GHG Inventory {yr}",
                 description=f"Scope 1/2/3 GHG inventory in tCO₂e for {yr}",
                 mimeType="application/json"),
        Resource(uri=f"esg://{t}/compliance",
                 name="Compliance Status",
                 description="ISO 14064 / ISO 50001 / GRI 305 / TCFD compliance status",
                 mimeType="application/json"),
        Resource(uri=f"esg://{t}/reports",
                 name="ESG Report History",
                 description="Auto-generated monthly ESG reports",
                 mimeType="application/json"),
        Resource(uri=f"esg://{t}/factors",
                 name="Emission Factors",
                 description="Registered GHG emission factor library",
                 mimeType="application/json"),
        Resource(uri=f"esg://{t}/issues",
                 name="Compliance Issues",
                 description="Open ESG compliance gaps and remediation steps",
                 mimeType="application/json"),
    ]

@server.read_resource()
async def read_resource(uri: str) -> str:
    t, yr = ID.tenant_id, datetime.utcnow().year
    routes = {
        f"esg://{t}/inventory/{yr}": ("/api/anab-esg/summary",{"year":yr}),
        f"esg://{t}/compliance":     ("/api/esg/compliance/status",{"year":yr}),
        f"esg://{t}/reports":        ("/api/esg/auto-reports",{}),
        f"esg://{t}/factors":        ("/api/anab-esg/emission-factors",{}),
        f"esg://{t}/issues":         ("/api/esg/compliance/issues",{"status":"open"}),
    }
    if uri not in routes:
        return json.dumps({"error":f"Unknown: {uri}"})
    path, params = routes[uri]
    try:
        return json.dumps({"tenant_id":t,"data":await C.get(path,params)},
                          ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"error":str(e)})

@server.list_tools()
async def list_tools():
    return [
        Tool(name="get_tenant_info",
             description="Return authenticated tenant identity.",
             inputSchema={"type":"object","properties":{}}),
        Tool(name="calculate_ghg_emissions",
             description="Calculate Scope 1/2/3 GHG emissions for a period in tCO₂e.",
             inputSchema={"type":"object","properties":{
                 "year":  {"type":"integer"},
                 "month": {"type":"integer","minimum":1,"maximum":12},
                 "scope": {"type":"string",
                           "enum":["scope1","scope2_location","scope2_market","scope3","all"],
                           "default":"all"},
             }}),
        Tool(name="generate_esg_report",
             description="Generate ISO 14064-compliant ESG report and email to tenant contact. ⚠️ Requires confirmed=true.",
             inputSchema={"type":"object","required":["year","month","confirmed"],"properties":{
                 "year":      {"type":"integer"},
                 "month":     {"type":"integer","minimum":1,"maximum":12},
                 "confirmed": {"type":"boolean"},
             }}),
        Tool(name="export_gri_report",
             description="Export GRI 305 Emissions disclosure as structured JSON.",
             inputSchema={"type":"object","required":["year"],"properties":{
                 "year": {"type":"integer"},
             }}),
        Tool(name="get_carbon_reduction_progress",
             description="YoY CO₂ reduction %, trajectory vs net-zero target, gap analysis.",
             inputSchema={"type":"object","properties":{
                 "year": {"type":"integer"},
             }}),
        Tool(name="get_emission_intensity",
             description="Emission intensity metrics: tCO₂e/m², tCO₂e/employee, tCO₂e/$M revenue.",
             inputSchema={"type":"object","properties":{
                 "year": {"type":"integer"},
             }}),
        Tool(name="identify_top_emission_sources",
             description="Rank emission sources by scope and type for reduction prioritisation.",
             inputSchema={"type":"object","properties":{
                 "year":  {"type":"integer"},
                 "top_n": {"type":"integer","default":5},
             }}),
        Tool(name="add_activity_data",
             description="Add a GHG activity record (electricity bill, gas, diesel). ⚠️ Requires confirmed=true.",
             inputSchema={"type":"object",
                          "required":["year","scope","source_type","activity_value",
                                      "activity_unit","emission_factor_id","confirmed"],
                          "properties":{
                              "year":               {"type":"integer"},
                              "scope":              {"type":"string",
                                                     "enum":["scope1","scope2_location",
                                                             "scope2_market","scope3"]},
                              "source_type":        {"type":"string"},
                              "activity_value":     {"type":"number"},
                              "activity_unit":      {"type":"string"},
                              "emission_factor_id": {"type":"integer"},
                              "facility_name":      {"type":"string"},
                              "confirmed":          {"type":"boolean"},
                          }}),
        Tool(name="resolve_compliance_issue",
             description="Mark an ESG compliance issue as resolved. ⚠️ Requires confirmed=true.",
             inputSchema={"type":"object","required":["issue_id","confirmed"],"properties":{
                 "issue_id":  {"type":"integer"},
                 "notes":     {"type":"string"},
                 "confirmed": {"type":"boolean"},
             }}),
        Tool(name="send_esg_slack_report",
             description="Send ESG report summary to the Slack channel.",
             inputSchema={"type":"object",
                          "required":["period","total_tco2e","score","currency","total_cost"],
                          "properties":{
                              "period":      {"type":"string","description":"e.g. May 2026"},
                              "total_tco2e": {"type":"number"},
                              "score":       {"type":"integer","minimum":0,"maximum":100},
                              "currency":    {"type":"string"},
                              "total_cost":  {"type":"number"},
                          }}),
    ]

@server.call_tool()
async def call_tool(name: str, arguments: dict):
    guard = tool_guard(name, arguments)
    if guard:
        return [TextContent(type="text", text=json.dumps(guard))]
    try:
        if name == "get_tenant_info":
            result = C.ctx()
        elif name == "calculate_ghg_emissions":
            result = await C.get("/api/esg/calculate", arguments, tool=name)
        elif name == "generate_esg_report":
            result = await C.post("/api/esg/generate-report", arguments, tool=name)
        elif name == "export_gri_report":
            result = await C.get("/api/esg/export/gri", arguments, tool=name)
        elif name == "get_carbon_reduction_progress":
            result = await C.get("/api/esg/reduction-progress", arguments, tool=name)
        elif name == "get_emission_intensity":
            result = await C.get("/api/esg/intensity", arguments, tool=name)
        elif name == "identify_top_emission_sources":
            result = await C.get("/api/esg/top-emission-sources", arguments, tool=name)
        elif name == "add_activity_data":
            result = await C.post("/api/anab-esg/activity-data", arguments, tool=name)
        elif name == "resolve_compliance_issue":
            result = await C.post(
                f"/api/esg/issues/{arguments['issue_id']}/resolve",
                {"notes":arguments.get("notes","")}, tool=name)
        elif name == "send_esg_slack_report":
            ok = await SLACK.esg_report(
                arguments["period"], arguments["total_tco2e"],
                arguments["score"], arguments["currency"], arguments["total_cost"])
            result = {"slack_sent": ok}
        else:
            result = {"error": f"Unknown tool: {name}"}
        return [TextContent(type="text",
                            text=json.dumps(result, ensure_ascii=False, indent=2))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({"error":str(e)}))]

@server.list_prompts()
async def list_prompts():
    return [
        Prompt(name="monthly_esg_summary",
               description="Full monthly ESG summary with compliance score and recommendations"),
        Prompt(name="carbon_reduction_roadmap",
               description="3-year carbon reduction roadmap toward net-zero"),
        Prompt(name="gri_305_disclosure",
               description="Prepare GRI 305 Emissions disclosure report"),
        Prompt(name="compliance_gap_analysis",
               description="Identify compliance gaps and provide remediation steps"),
    ]

@server.get_prompt()
async def get_prompt(name: str, arguments=None):
    co = ID.company_name or ID.tenant_id
    now = datetime.utcnow()
    tpl = {
        "monthly_esg_summary": (
            f"Generate {now.strftime('%B %Y')} ESG summary for {co} ({ID.tenant_id}). "
            "Call calculate_ghg_emissions (scope=all) and get_carbon_reduction_progress. "
            "Then call send_esg_slack_report with the results. "
            "Report: emissions by scope (tCO₂e), compliance score, YoY comparison, "
            "top 3 emission sources, and 3 actions to improve next month."
        ),
        "carbon_reduction_roadmap": (
            f"Create a 3-year carbon reduction roadmap for {co} ({ID.tenant_id}). "
            "Call get_carbon_reduction_progress and identify_top_emission_sources. "
            "Output: current baseline, annual reduction targets (%), "
            "specific actions per year, estimated cost savings."
        ),
        "gri_305_disclosure": (
            f"Prepare GRI 305 disclosure for {co} ({ID.tenant_id}). "
            f"Call export_gri_report (year={now.year}). "
            "Format as standard GRI 305 table: "
            "305-1 (Scope 1), 305-2 (Scope 2), 305-3 (Scope 3), "
            "305-4 (GHG intensity), 305-5 (GHG reduction)."
        ),
        "compliance_gap_analysis": (
            f"Analyze compliance gaps for {co} ({ID.tenant_id}). "
            f"Read esg://{ID.tenant_id}/compliance and esg://{ID.tenant_id}/issues. "
            "For each gap: standard clause, severity, deadline, remediation steps. "
            "Sort by severity (critical first)."
        ),
    }
    return GetPromptResult(
        description=name,
        messages=[PromptMessage(role="user",
                                content=TextContent(type="text",
                                                    text=tpl.get(name,f"Analyze ESG for {ID.tenant_id}.")))])

async def main():
    async with stdio_server() as (r, w):
        await server.run(r, w, server.create_initialization_options())

if __name__ == "__main__":
    asyncio.run(main())
