"""
AsterStream EMS MCP Server — Energy Management (Secure Multi-Tenant)
=====================================================================
Tools: 11  Resources: 5  Prompts: 4
One process = one tenant. AI cannot access other tenants' data.
"""
import asyncio, json, sys, os, logging
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from datetime import datetime
from shared.security import load_ems_identity, SecureClient, tool_guard
from shared.slack_client import SlackClient
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Resource, Tool, TextContent, Prompt, PromptMessage, GetPromptResult

logging.basicConfig(level=logging.INFO)
ID     = load_ems_identity()
C      = SecureClient(ID)
SLACK  = SlackClient(ID.company_name)
server = Server("asterstream-ems")

@server.list_resources()
async def list_resources():
    t = ID.tenant_id
    return [
        Resource(uri=f"ems://{t}/sites",    name="Sites",
                 description=f"Monitored sites — {ID.company_name or t}",
                 mimeType="application/json"),
        Resource(uri=f"ems://{t}/devices",  name="Devices",
                 description="All IoT devices: chillers, HVAC, meters, EV chargers",
                 mimeType="application/json"),
        Resource(uri=f"ems://{t}/energy",   name="Energy Today",
                 description="Real-time energy consumption summary",
                 mimeType="application/json"),
        Resource(uri=f"ems://{t}/alerts",   name="Active Alerts",
                 description="Unresolved device alarms",
                 mimeType="application/json"),
        Resource(uri=f"ems://{t}/ai/recs",  name="AI Recommendations",
                 description="Pending AI energy-saving suggestions",
                 mimeType="application/json"),
    ]

@server.read_resource()
async def read_resource(uri: str) -> str:
    t = ID.tenant_id
    routes = {
        f"ems://{t}/sites":   ("/api/sites",{}),
        f"ems://{t}/devices": ("/api/devices",{}),
        f"ems://{t}/energy":  ("/api/energy/summary",{"period":"today"}),
        f"ems://{t}/alerts":  ("/api/alarms",{"resolved":"false"}),
        f"ems://{t}/ai/recs": ("/api/ai/recommendations",{"status":"Pending"}),
    }
    if uri not in routes:
        return json.dumps({"error":f"Unknown resource: {uri}"})
    path, params = routes[uri]
    try:
        data = await C.get(path, params)
        return json.dumps({"tenant_id":t,"data":data}, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"error":str(e)})

@server.list_tools()
async def list_tools():
    return [
        Tool(name="get_tenant_info",
             description="Return authenticated tenant identity and active plan.",
             inputSchema={"type":"object","properties":{}}),
        Tool(name="get_building_power_usage",
             description="Energy consumption (kWh, kW demand, PF, CO₂, cost) for this tenant.",
             inputSchema={"type":"object","properties":{
                 "site_id": {"type":"integer","description":"Site ID (omit = all sites)"},
                 "period":  {"type":"string","enum":["realtime","today","week","month","year"],
                             "default":"today"},
             }}),
        Tool(name="get_realtime_meter",
             description="Latest meter reading for one device.",
             inputSchema={"type":"object","required":["device_id"],
                          "properties":{"device_id":{"type":"integer"}}}),
        Tool(name="detect_energy_anomaly",
             description="AI anomaly detection — devices consuming above baseline threshold.",
             inputSchema={"type":"object","properties":{
                 "site_id":       {"type":"integer"},
                 "threshold_pct": {"type":"number","default":20,
                                   "description":"% above baseline to flag"},
                 "period":        {"type":"string","default":"today"},
             }}),
        Tool(name="shutdown_idle_equipment",
             description="Turn off idle devices. ⚠️ Requires confirmed=true.",
             inputSchema={"type":"object","required":["device_ids","confirmed"],
                          "properties":{
                              "device_ids":{"type":"array","items":{"type":"integer"}},
                              "reason":    {"type":"string"},
                              "confirmed": {"type":"boolean",
                                           "description":"Must be true to execute"},
                          }}),
        Tool(name="set_device_setpoint",
             description="Change setpoint (temperature/power) for chiller or AHU. ⚠️ Requires confirmed=true.",
             inputSchema={"type":"object",
                          "required":["device_id","setpoint_type","value","confirmed"],
                          "properties":{
                              "device_id":    {"type":"integer"},
                              "setpoint_type":{"type":"string",
                                              "enum":["temperature","power_kw","speed_pct"]},
                              "value":        {"type":"number"},
                              "unit":         {"type":"string","default":"°C"},
                              "reason":       {"type":"string"},
                              "confirmed":    {"type":"boolean"},
                          }}),
        Tool(name="get_energy_cost_analysis",
             description="Peak/off-peak kWh, demand charges, PF penalty, total bill in tenant currency.",
             inputSchema={"type":"object","properties":{
                 "year":    {"type":"integer"},
                 "month":   {"type":"integer","minimum":1,"maximum":12},
                 "site_id": {"type":"integer"},
             }}),
        Tool(name="approve_ai_recommendation",
             description="Approve and execute a pending AI recommendation. ⚠️ Requires confirmed=true.",
             inputSchema={"type":"object","required":["recommendation_id","confirmed"],
                          "properties":{
                              "recommendation_id":{"type":"integer"},
                              "confirmed":        {"type":"boolean"},
                          }}),
        Tool(name="forecast_energy_usage",
             description="AI energy forecast for next N days (Prophet + XGBoost).",
             inputSchema={"type":"object","properties":{
                 "days":    {"type":"integer","default":7},
                 "site_id": {"type":"integer"},
             }}),
        Tool(name="get_power_alert_events",
             description="Recent power alerts: kW spikes, poor PF, high current, voltage anomalies.",
             inputSchema={"type":"object","properties":{
                 "status":{"type":"string",
                           "enum":["active","acknowledged","resolved"],"default":"active"},
                 "limit": {"type":"integer","default":20},
             }}),
        Tool(name="send_slack_alert",
             description="Send an energy alert notification to the Slack channel.",
             inputSchema={"type":"object",
                          "required":["device_name","deviation_pct","current_kw","action"],
                          "properties":{
                              "device_name":   {"type":"string"},
                              "deviation_pct": {"type":"number"},
                              "current_kw":    {"type":"number"},
                              "action":        {"type":"string"},
                          }}),
    ]

@server.call_tool()
async def call_tool(name: str, arguments: dict):
    guard = tool_guard(name, arguments)
    if guard:
        return [TextContent(type="text", text=json.dumps(guard))]
    try:
        if name == "get_tenant_info":
            result = C.ctx()
        elif name == "get_building_power_usage":
            result = await C.get("/api/energy/usage", arguments, tool=name)
        elif name == "get_realtime_meter":
            result = await C.get(f"/api/devices/{arguments['device_id']}/reading",
                                 tool=name)
        elif name == "detect_energy_anomaly":
            result = await C.get("/api/ai/anomaly-detection", arguments, tool=name)
        elif name == "shutdown_idle_equipment":
            out = []
            for did in arguments.get("device_ids",[]):
                r = await C.post("/api/devices/command",{
                    "device_id":did,"command_type":"turn_off",
                    "source":"mcp_agent","reason":arguments.get("reason","")},
                    tool=name)
                out.append(r)
            result = {"commands_issued":len(out),"details":out}
        elif name == "set_device_setpoint":
            result = await C.post("/api/devices/command",{
                "device_id":arguments["device_id"],"command_type":"set_setpoint",
                "payload":{
                    "setpoint_type":arguments["setpoint_type"],
                    "value":arguments["value"],
                    "unit":arguments.get("unit","°C"),
                },"source":"mcp_agent","reason":arguments.get("reason","")},
                tool=name)
        elif name == "get_energy_cost_analysis":
            result = await C.get("/api/energy/cost-analysis", arguments, tool=name)
        elif name == "approve_ai_recommendation":
            result = await C.post(
                f"/api/ai/recommendations/{arguments['recommendation_id']}/approve",{},
                tool=name)
        elif name == "forecast_energy_usage":
            result = await C.post("/api/ai/forecast", arguments, tool=name)
        elif name == "get_power_alert_events":
            result = await C.get("/api/power-alerts/events", arguments, tool=name)
        elif name == "send_slack_alert":
            ok = await SLACK.energy_alert(
                arguments["device_name"],
                arguments["deviation_pct"],
                arguments["current_kw"],
                arguments["action"],
            )
            result = {"slack_sent": ok}
        else:
            result = {"error": f"Unknown tool: {name}"}
        return [TextContent(type="text",
                            text=json.dumps(result, ensure_ascii=False, indent=2))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({"error":str(e)}))]

@server.list_prompts()
async def list_prompts():
    return [
        Prompt(name="analyze_monthly_energy",
               description="Full monthly energy cost analysis with top savings recommendations"),
        Prompt(name="detect_anomalies_today",
               description="Check today's readings for anomalies and suggest immediate actions"),
        Prompt(name="peak_reduction_plan",
               description="Create a peak demand reduction plan to cut electricity bills"),
        Prompt(name="nightly_shutdown_check",
               description="List equipment to shut down after business hours (after 22:00)"),
    ]

@server.get_prompt()
async def get_prompt(name: str, arguments=None):
    co = ID.company_name or ID.tenant_id
    now = datetime.utcnow()
    tpl = {
        "analyze_monthly_energy": (
            f"Analyze energy data for {co} (Tenant: {ID.tenant_id}). "
            f"Call get_energy_cost_analysis for {now.year}/{now.month} "
            "and get_building_power_usage with period=month. "
            "Report: total kWh and cost, peak vs off-peak split, top 3 consuming devices, "
            "power factor, and 3 specific actions to reduce cost by ≥10% next month."
        ),
        "detect_anomalies_today": (
            f"Check energy anomalies for {co} ({ID.tenant_id}) today. "
            "Call detect_energy_anomaly (threshold_pct=15, period=today). "
            "For each flagged device, call get_realtime_meter. "
            "If anomaly >30%, call send_slack_alert with the finding. "
            "Report: device name, deviation %, current reading, recommended action."
        ),
        "peak_reduction_plan": (
            f"Analyze peak demand for {co} ({ID.tenant_id}). "
            "Use get_energy_cost_analysis to find demand charge % of total bill. "
            "Use detect_energy_anomaly to find peak-hour offenders. "
            "Output: load-shifting schedule, target kW reduction, estimated monthly savings."
        ),
        "nightly_shutdown_check": (
            f"It is after 22:00. Check idle equipment for {co} ({ID.tenant_id}). "
            "Call get_building_power_usage (period=realtime). "
            "List devices still on that should be off — include device IDs and current kW. "
            "Add confirmed=true to arguments, then wait for user approval before calling "
            "shutdown_idle_equipment."
        ),
    }
    return GetPromptResult(
        description=name,
        messages=[PromptMessage(role="user",
                                content=TextContent(type="text",
                                                    text=tpl.get(name, f"Analyze energy for {ID.tenant_id}.")))])

async def main():
    async with stdio_server() as (r, w):
        await server.run(r, w, server.create_initialization_options())

if __name__ == "__main__":
    asyncio.run(main())
