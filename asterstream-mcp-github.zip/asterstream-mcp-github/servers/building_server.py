"""
AsterStream Smart Building & AIOps MCP Server (Secure Multi-Tenant)
====================================================================
Tools: 11  Resources: 4  Prompts: 4
"""
import asyncio, json, sys, os, logging
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from datetime import datetime
from shared.security import load_ems_identity, SecureClient, tool_guard
from shared.slack_client import SlackClient
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Resource, Tool, TextContent, Prompt, PromptMessage, GetPromptResult

logging.basicConfig(level=logging.INFO)
ID    = load_ems_identity()
C     = SecureClient(ID)
SLACK = SlackClient(ID.company_name)
server = Server("asterstream-building")

@server.list_resources()
async def list_resources():
    t = ID.tenant_id
    return [
        Resource(uri=f"bld://{t}/gateways",  name="IoT Gateways",
                 description="All gateways with heartbeat and connection status",
                 mimeType="application/json"),
        Resource(uri=f"bld://{t}/offline",   name="Offline Devices",
                 description="Devices offline in the last 24 hours",
                 mimeType="application/json"),
        Resource(uri=f"bld://{t}/ev/status", name="EV Charging Status",
                 description="EV charging stations — sessions and energy delivered",
                 mimeType="application/json"),
        Resource(uri=f"bld://{t}/schedules", name="Device Schedules",
                 description="Active on/off schedules for all devices",
                 mimeType="application/json"),
    ]

@server.read_resource()
async def read_resource(uri: str) -> str:
    t = ID.tenant_id
    routes = {
        f"bld://{t}/gateways":  ("/api/gateways/status",{}),
        f"bld://{t}/offline":   ("/api/devices/offline",{"hours":24}),
        f"bld://{t}/ev/status": ("/api/ev/charging-status",{}),
        f"bld://{t}/schedules": ("/api/device-schedules",{"active":"true"}),
    }
    if uri not in routes:
        return json.dumps({"error":f"Unknown: {uri}"})
    path, params = routes[uri]
    try:
        return json.dumps({"tenant_id":t,"data":await C.get(path,params)},
                          ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"error":str(e)})

@server.list_tools()
async def list_tools():
    return [
        Tool(name="get_tenant_info",
             description="Return authenticated tenant identity.",
             inputSchema={"type":"object","properties":{}}),
        Tool(name="get_building_occupancy",
             description="Current occupancy per floor/zone.",
             inputSchema={"type":"object","properties":{
                 "site_id":     {"type":"integer"},
                 "building_id": {"type":"integer"},
             }}),
        Tool(name="set_zone_hvac",
             description="Set HVAC temperature/mode for a zone. ⚠️ Requires confirmed=true.",
             inputSchema={"type":"object","required":["device_id","temperature","confirmed"],
                          "properties":{
                              "device_id":   {"type":"integer"},
                              "temperature": {"type":"number"},
                              "mode":        {"type":"string",
                                             "enum":["cool","heat","auto","off"],"default":"cool"},
                              "zone":        {"type":"string"},
                              "confirmed":   {"type":"boolean"},
                          }}),
        Tool(name="get_device_health",
             description="Health status, last reading, maintenance history for one device.",
             inputSchema={"type":"object","required":["device_id"],
                          "properties":{"device_id":{"type":"integer"}}}),
        Tool(name="predict_device_failure",
             description="AI failure prediction (Isolation Forest model). Returns probability and recommended action.",
             inputSchema={"type":"object","required":["device_id"],"properties":{
                 "device_id":      {"type":"integer"},
                 "lookahead_days": {"type":"integer","default":7},
             }}),
        Tool(name="schedule_device",
             description="Set automatic on/off schedule for a device. ⚠️ Requires confirmed=true.",
             inputSchema={"type":"object","required":["device_id","schedules","confirmed"],
                          "properties":{
                              "device_id": {"type":"integer"},
                              "schedules": {
                                  "type":"array",
                                  "items":{"type":"object","properties":{
                                      "weekdays":{"type":"array","items":{"type":"string"}},
                                      "on_time": {"type":"string","description":"HH:MM"},
                                      "off_time":{"type":"string","description":"HH:MM"},
                                  }},
                              },
                              "confirmed":{"type":"boolean"},
                          }}),
        Tool(name="get_ev_charging_status",
             description="EV charging station status, active sessions, energy delivered.",
             inputSchema={"type":"object","properties":{
                 "site_id":{"type":"integer"},
             }}),
        Tool(name="get_platform_health",
             description="Platform health: API latency, DB, MQTT, gateway connectivity.",
             inputSchema={"type":"object","properties":{}}),
        Tool(name="get_offline_devices",
             description="Devices offline in the last N hours.",
             inputSchema={"type":"object","properties":{
                 "hours":  {"type":"integer","default":24},
                 "site_id":{"type":"integer"},
             }}),
        Tool(name="trigger_device_diagnostics",
             description="Run remote diagnostics on a device (ping/selftest/calibrate).",
             inputSchema={"type":"object","required":["device_id"],"properties":{
                 "device_id":{"type":"integer"},
                 "type":     {"type":"string","enum":["ping","selftest","calibrate"],
                              "default":"ping"},
             }}),
        Tool(name="send_device_offline_slack",
             description="Send device offline alert to Slack.",
             inputSchema={"type":"object","required":["device_name","site","hours_offline"],
                          "properties":{
                              "device_name":  {"type":"string"},
                              "site":         {"type":"string"},
                              "hours_offline":{"type":"number"},
                          }}),
    ]

@server.call_tool()
async def call_tool(name: str, arguments: dict):
    guard = tool_guard(name, arguments)
    if guard:
        return [TextContent(type="text", text=json.dumps(guard))]
    try:
        if name == "get_tenant_info":
            result = C.ctx()
        elif name == "get_building_occupancy":
            result = await C.get("/api/buildings/occupancy", arguments, tool=name)
        elif name == "set_zone_hvac":
            result = await C.post("/api/devices/command",{
                "device_id":arguments["device_id"],"command_type":"set_setpoint",
                "payload":{
                    "setpoint_type":"temperature","value":arguments["temperature"],
                    "mode":arguments.get("mode","cool"),"zone":arguments.get("zone",""),
                },"source":"mcp_agent"}, tool=name)
        elif name == "get_device_health":
            result = await C.get(f"/api/devices/{arguments['device_id']}/health", tool=name)
        elif name == "predict_device_failure":
            result = await C.post("/api/ai/predict-failure", arguments, tool=name)
        elif name == "schedule_device":
            result = await C.post("/api/device-schedules", arguments, tool=name)
        elif name == "get_ev_charging_status":
            result = await C.get("/api/ev/charging-status", arguments, tool=name)
        elif name == "get_platform_health":
            result = await C.get("/api/system/health", tool=name)
        elif name == "get_offline_devices":
            result = await C.get("/api/devices/offline", arguments, tool=name)
        elif name == "trigger_device_diagnostics":
            result = await C.post("/api/devices/diagnostics", arguments, tool=name)
        elif name == "send_device_offline_slack":
            ok = await SLACK.device_offline(
                arguments["device_name"], arguments["site"],
                arguments["hours_offline"])
            result = {"slack_sent": ok}
        else:
            result = {"error": f"Unknown tool: {name}"}
        return [TextContent(type="text",
                            text=json.dumps(result, ensure_ascii=False, indent=2))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({"error":str(e)}))]

@server.list_prompts()
async def list_prompts():
    return [
        Prompt(name="nightly_shutdown",
               description="List equipment to shut down after business hours (after 22:00)"),
        Prompt(name="maintenance_schedule",
               description="Generate weekly maintenance schedule from AI failure predictions"),
        Prompt(name="morning_startup_optimize",
               description="Optimize building startup sequence to minimize peak demand"),
        Prompt(name="weekly_aiops_report",
               description="Generate weekly AIOps operations summary report"),
    ]

@server.get_prompt()
async def get_prompt(name: str, arguments=None):
    co = ID.company_name or ID.tenant_id
    tpl = {
        "nightly_shutdown": (
            f"After 22:00. Find idle equipment for {co} ({ID.tenant_id}). "
            "Call get_building_occupancy to check occupied zones. "
            "Call get_offline_devices (hours=1) for already-off devices. "
            "List HVAC/lighting still on in unoccupied floors. "
            "Show device IDs and kW. Use confirmed=true, then ask user approval "
            "before calling set_zone_hvac (mode=off)."
        ),
        "maintenance_schedule": (
            f"Generate weekly maintenance schedule for {co} ({ID.tenant_id}). "
            "Call predict_device_failure for all warning-status devices. "
            "For devices with failure probability >60%, call get_device_health. "
            "Output: priority-sorted list with device name, probability, recommended date."
        ),
        "morning_startup_optimize": (
            f"It is 07:00. Optimize building startup for {co} ({ID.tenant_id}). "
            "Call get_building_occupancy for expected occupancy today. "
            "Call get_platform_health to verify all gateways are online. "
            "Recommend HVAC pre-cooling sequence to reach comfort temperature by 09:00 "
            "while minimising peak demand. Output: startup timetable and setpoints."
        ),
        "weekly_aiops_report": (
            f"Generate weekly AIOps report for {co} ({ID.tenant_id}). "
            "Call get_platform_health, get_offline_devices (hours=168). "
            "Output: device uptime %, gateway reliability, top recurring issues, "
            "infrastructure improvement recommendations. "
            "If any device was offline >4 hours, call send_device_offline_slack."
        ),
    }
    return GetPromptResult(
        description=name,
        messages=[PromptMessage(role="user",
                                content=TextContent(type="text",
                                                    text=tpl.get(name,f"Analyze building for {ID.tenant_id}.")))])

async def main():
    async with stdio_server() as (r, w):
        await server.run(r, w, server.create_initialization_options())

if __name__ == "__main__":
    asyncio.run(main())
