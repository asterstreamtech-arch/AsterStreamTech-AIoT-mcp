# AsterStream MCP — Enterprise Energy & ESG AI Connectivity

[![MCP Compatible](https://img.shields.io/badge/MCP-Compatible-00C9A7?style=flat-square)](https://modelcontextprotocol.io)
[![Python](https://img.shields.io/badge/Python-3.10%2B-blue?style=flat-square)](https://python.org)
[![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)](LICENSE)
[![Publisher](https://img.shields.io/badge/Publisher-Aster%20Stream%20Tech%20Pte.%20Ltd.-navy?style=flat-square)](https://asterstreamtech.com)

> Connect AI agents to real-time **Energy Management**, **ESG Carbon Reporting**, and **Smart Building** data through the Model Context Protocol (MCP).

---

## What is AsterStream MCP?

AsterStream MCP is a suite of **4 enterprise-grade MCP servers** that give AI agents — Claude, Cursor, Copilot, GPT-4, and any MCP-compatible client — secure, real-time access to operational energy and sustainability data.

Built for **enterprises, factories, green buildings, and ESG teams** across Singapore, Taiwan, Malaysia, India, Indonesia, Thailand, Vietnam, and the Philippines.

### Key Capabilities

- ⚡ **Real-time energy data** — kWh, kW demand, power factor, CO₂ emissions, electricity cost
- 🌱 **ISO 14064 GHG reporting** — Scope 1, 2, and 3 calculations; GRI 305 export; TCFD disclosure
- 🤖 **AI anomaly detection** — Isolation Forest + XGBoost identify abnormal energy consumption
- 📈 **AI forecasting** — Prophet + XGBoost predict energy usage for the next N days
- 🏢 **Smart building control** — HVAC setpoints, occupancy-aware scheduling, EV charging, predictive maintenance
- 🔐 **Enterprise security** — 9-layer security, multi-tenant isolation, prompt injection protection

---

## MCP Servers

| Server | Name | Use Case |
|--------|------|----------|
| `ems_server.py` | `asterstream-ems` | Energy monitoring, anomaly detection, cost analysis |
| `esg_server.py` | `asterstream-esg` | Carbon accounting, ISO 14064, GRI 305 reporting |
| `building_server.py` | `asterstream-building` | HVAC control, predictive maintenance, EV charging |
| `portal_server.py` | `asterstream-portal` | API key management, usage analytics, billing |

---

## Quick Start

### Prerequisites

- Python 3.10 or higher
- An AsterStream account — [mcp.asterstreamtech.com](https://mcp.asterstreamtech.com) (14-day free trial)

### Installation

```bash
git clone https://github.com/asterstream/asterstream-mcp.git
cd asterstream-mcp
pip install -r requirements.txt
```

### Configuration

```bash
cp config/.env.example .env
```

Edit `.env` with your credentials from the [Dashboard](https://mcp.asterstreamtech.com/Dashboard):

```env
ASTERSTREAM_API_TOKEN=ast_live_your_token_here
ASTERSTREAM_TENANT_ID=your_company_registration_number
TENANT_COMPANY_NAME=Your Company Name
TENANT_COUNTRY_CODE=SG
```

### Claude Desktop Setup

Add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "asterstream-ems": {
      "command": "python",
      "args": ["/path/to/asterstream-mcp/servers/ems_server.py"],
      "env": {
        "ASTERSTREAM_API_TOKEN": "ast_live_your_token",
        "ASTERSTREAM_TENANT_ID": "your_registration_number",
        "TENANT_COMPANY_NAME":   "Your Company Name",
        "TENANT_COUNTRY_CODE":   "SG"
      }
    }
  }
}
```

Config file location:

| Platform | Path |
|----------|------|
| macOS | `~/Library/Application Support/Claude/claude_desktop_config.json` |
| Windows | `%APPDATA%\Claude\claude_desktop_config.json` |
| Linux | `~/.config/Claude/claude_desktop_config.json` |

---

## Tools Reference

### ⚡ EMS Server (`asterstream-ems`)

| Tool | Description |
|------|-------------|
| `get_tenant_info` | Return authenticated tenant identity and subscription plan |
| `get_building_power_usage` | kWh, kW demand, power factor, CO₂, and cost by site and period |
| `get_realtime_meter` | Latest real-time meter reading for a specific device |
| `detect_energy_anomaly` | AI anomaly detection — identify devices consuming above baseline |
| `get_energy_cost_analysis` | Peak/off-peak kWh, demand charges, PF penalty, total electricity bill |
| `forecast_energy_usage` | AI energy forecast for next N days using Prophet + XGBoost |
| `get_power_alert_events` | Recent alerts: kW spikes, poor power factor, voltage anomalies |
| `approve_ai_recommendation` | Execute a pending AI energy-saving recommendation |
| `shutdown_idle_equipment` | Turn off idle equipment *(requires `confirmed=true`)* |
| `set_device_setpoint` | Change temperature or power setpoint on a device |
| `send_slack_alert` | Send energy anomaly alert to a Slack channel |

**Prompts:** `analyze_monthly_energy`, `detect_anomalies_today`, `peak_reduction_plan`, `nightly_shutdown_check`

---

### 🌱 ESG Server (`asterstream-esg`)

| Tool | Description |
|------|-------------|
| `get_tenant_info` | Return authenticated tenant identity |
| `calculate_ghg_emissions` | Scope 1, 2, and 3 GHG emissions in tCO₂e for a date range |
| `export_gri_report` | GRI 305 Emissions disclosure as structured JSON |
| `get_carbon_reduction_progress` | Year-over-year reduction % vs net-zero trajectory |
| `get_emission_intensity` | tCO₂e per m², per employee, per $M revenue |
| `identify_top_emission_sources` | Ranked list of emission sources for reduction prioritisation |
| `generate_esg_report` | Generate ISO 14064 report and email to tenant contact |
| `add_activity_data` | Add GHG activity data record (electricity, gas, diesel, refrigerant) |
| `resolve_compliance_issue` | Mark an ESG compliance issue as resolved |
| `send_esg_slack_report` | Send ESG summary report to Slack |

**Supported standards:** ISO 14064-1, ISO 14067, GRI 305, TCFD, ISO 50001

**Country emission factors:**

| Country | Grid Factor | Source |
|---------|------------|--------|
| SG | 0.4168 kgCO₂/kWh | EMA Singapore |
| TW | 0.4990 kgCO₂/kWh | MOEA Taiwan |
| MY | 0.7850 kgCO₂/kWh | Suruhanjaya Tenaga |
| IN | 0.7082 kgCO₂/kWh | Ministry of Power |
| ID | 0.8760 kgCO₂/kWh | PLN Indonesia |
| TH | 0.4999 kgCO₂/kWh | EGAT Thailand |

---

### 🏢 Building Server (`asterstream-building`)

| Tool | Description |
|------|-------------|
| `get_tenant_info` | Return authenticated tenant identity |
| `get_building_occupancy` | Current occupancy per floor and zone |
| `get_device_health` | Device health status, last reading, maintenance history |
| `predict_device_failure` | AI failure prediction using Isolation Forest model |
| `get_ev_charging_status` | EV charging stations — active sessions and energy delivered |
| `get_platform_health` | API latency, database, MQTT broker, and gateway connectivity |
| `get_offline_devices` | Devices that have gone offline in the last N hours |
| `trigger_device_diagnostics` | Remote device diagnostics: ping, self-test, calibrate |
| `get_nightly_summary` | Overnight operations summary: offline devices, anomalies |
| `set_zone_hvac` | Set HVAC temperature and mode for a building zone *(requires `confirmed=true`)* |
| `schedule_device` | Set automatic on/off schedule for a device *(requires `confirmed=true`)* |
| `send_device_offline_slack` | Send device offline alert to Slack |

---

### 🔑 Portal Server (`asterstream-portal`)

| Tool | Description |
|------|-------------|
| `get_tenant_info` | Return authenticated portal tenant identity |
| `get_my_usage_stats` | API call count, error rate, top endpoints this month |
| `list_my_api_keys` | All API keys with usage, status, and expiry |
| `get_my_subscription` | Plan, billing cycle, trial status, next invoice date |
| `get_api_error_analysis` | Error types, frequency, and affected endpoints |
| `get_my_invoices` | Invoice history with amounts and PDF download links |
| `get_usage_forecast` | Predict whether monthly API quota will be exceeded |
| `create_api_key` | Create a new API key *(requires `confirmed=true`)* |
| `revoke_api_key` | Revoke an API key immediately *(requires `confirmed=true`)* |
| `send_quota_warning_slack` | Send quota warning notification to Slack |

---

## Security Architecture

AsterStream MCP is designed for enterprise multi-tenant deployments. **Cross-tenant data access is structurally impossible**, not just policy-controlled.

### Nine Security Layers

| Layer | Mechanism |
|-------|-----------|
| 1 | **TenantId binding** — frozen `dataclass(frozen=True)` at process startup |
| 2 | **X-Tenant-Id header** — injected into every HTTP request |
| 3 | **Query param injection** — `?tenant_id=` appended to every GET request |
| 4 | **POST body injection** — `{"tenant_id":…}` included in every POST |
| 5 | **Argument scrubbing** — AI-supplied `tenant_id` stripped and replaced |
| 6 | **Prompt injection detection** — 15+ attack patterns blocked before tool execution |
| 7 | **Rate limiting** — max 20 tool calls/min per server process |
| 8 | **Write confirmation** — destructive tools require `confirmed=true` |
| 9 | **Token masking** — API tokens never appear in logs |

### Write Operation Protection

Tools that modify system state require explicit confirmation:

```python
# Without confirmed=true:
{
  "requires_confirmation": true,
  "tool": "shutdown_idle_equipment",
  "message": "Add confirmed=true to proceed."
}
```

### Subscription Validation

Every tool call is validated against the portal before execution:

```
POST https://mcp.asterstreamtech.com/api/mcp/validate
→ Checks: API key, subscription status, sites quota, devices quota, monthly API quota
```

---

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `ASTERSTREAM_API_TOKEN` | ✅ | API token from Dashboard → API Keys |
| `ASTERSTREAM_TENANT_ID` | ✅ | Company registration number (UEN/統一編號/CIN) |
| `ASTERSTREAM_API_BASE` | No | API base URL (default: `https://asterstreambuild.com`) |
| `TENANT_COMPANY_NAME` | No | Company name for Slack notifications |
| `TENANT_COUNTRY_CODE` | No | ISO code: SG/TW/MY/IN/ID/TH/VN/PH (default: SG) |
| `TENANT_PLAN` | No | Plan code: starter/professional/business/enterprise |
| `PORTAL_VALIDATE_URL` | No | Subscription validation endpoint |
| `VALIDATION_CACHE_SECS` | No | Validation cache TTL in seconds (default: 300) |
| `SLACK_WEBHOOK_URL` | No | Slack Incoming Webhook URL for notifications |

---

## Supported Countries

| Code | Country | Registration Format |
|------|---------|---------------------|
| SG | Singapore | UEN — e.g. `202512345A` |
| TW | Taiwan | 統一編號 — 8 digits |
| MY | Malaysia | SSM — e.g. `1234567-A` |
| IN | India | CIN — e.g. `U12345MH2020PTC123456` |
| ID | Indonesia | NIB / NPWP |
| TH | Thailand | Juristic ID — 13 digits |
| VN | Vietnam | MST — Tax ID |
| PH | Philippines | SEC / DTI Number |

---

## Example Conversations

**Energy Analysis:**
```
User: Analyze this month's energy consumption and identify cost-saving opportunities

Claude: Analyzed 48,320 kWh across 3 sites for May 2026:
  • Total cost: SGD 8,217
  • Peak demand charge: SGD 1,488 (Chiller Plant: 124 kW peak)
  • Top anomaly: Chiller C-02 running 26% above baseline
  • Recommendation: Pre-cool 30 min earlier → estimated SGD 340/month saving
```

**ESG Reporting:**
```
User: Generate our Q1 2026 GHG inventory report for ISO 14064 submission

Claude: Q1 2026 GHG Inventory (ISO 14064-1):
  • Scope 1 (direct): 12.4 tCO₂e — diesel generator, refrigerant
  • Scope 2 (electricity): 89.3 tCO₂e — grid emission factor 0.4168 kgCO₂/kWh
  • Scope 3 (upstream): 24.1 tCO₂e — business travel, supply chain
  • Total: 125.8 tCO₂e | YoY reduction: 8.3%
  Report generated and emailed to compliance@yourcompany.com
```

**Smart Building:**
```
User: Which equipment should we shut down tonight after 10 PM?

Claude: Recommended nightly shutdown list:
  • AHU-03 (Floor 4) — 0 occupancy since 18:30, saves 12 kWh
  • Chiller CWP-02 — partial load, switch to single chiller mode
  • EV Charger Bay 5-8 — no active sessions, defer to off-peak rate
  Estimated savings: SGD 28 tonight / SGD 840/month
```

---

## Subscription Plans

| Plan | Monthly | Sites | Devices | API calls/mo |
|------|---------|-------|---------|-------------|
| Starter | $49 USD | 1 | 50 | 10,000 |
| Professional | $199 USD | 5 | 500 | 100,000 |
| Business | $499 USD | 20 | 5,000 | 1,000,000 |
| Enterprise | Custom | ∞ | ∞ | ∞ |

**14-day free trial — no credit card required.**
Sign up at [mcp.asterstreamtech.com](https://mcp.asterstreamtech.com)

---

## Project Structure

```
asterstream-mcp/
├── servers/
│   ├── ems_server.py          Energy Management MCP Server
│   ├── esg_server.py          ESG & Carbon MCP Server
│   ├── building_server.py     Smart Building MCP Server
│   └── portal_server.py       Portal Management MCP Server
├── shared/
│   ├── security.py            Multi-layer security module
│   └── slack_client.py        Slack notification client
├── config/
│   ├── .env.example           Environment variables template
│   └── claude_desktop_config.json   Claude Desktop config template
├── docs/
│   ├── TOOLS.md               Full tool reference
│   ├── SECURITY.md            Security architecture detail
│   └── CHANGELOG.md           Version history
├── requirements.txt           Python dependencies
├── README.md                  This file
└── LICENSE                    MIT License
```

---

## Dependencies

```
mcp>=1.0.0          Anthropic MCP SDK
httpx>=0.27.0       Async HTTP client
python-dotenv>=1.0.0 Environment variable loader
anyio>=4.0.0        Async I/O support
```

---

## License

MIT License — see [LICENSE](LICENSE)

---

## Publisher

**Aster Stream Tech Pte. Ltd.**
Singapore | UEN: 202554923M

- 🌐 [asterstreamtech.com](https://asterstreamtech.com)
- 🔌 [mcp.asterstreamtech.com](https://mcp.asterstreamtech.com)
- 📧 aster.stream.tech@gmail.com
- 📖 [Documentation](https://mcp.asterstreamtech.com/Docs)
