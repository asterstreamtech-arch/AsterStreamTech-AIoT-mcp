# AsterStream MCP HTTP Server — Vercel Deployment

MCP HTTP Server for Smithery.ai integration.
Implements MCP Streamable HTTP transport + SSE fallback.

**Publisher:** Aster Stream Tech Pte. Ltd. (Singapore)
**Portal:** https://mcp.asterstreamtech.com

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/` | Health check — server info |
| POST | `/mcp` | MCP Streamable HTTP transport (main) |
| GET | `/sse` | SSE transport (fallback) |
| POST | `/messages` | SSE message receiver |

## Tools Available

- `get_tenant_info` — Tenant identity and subscription info
- `get_building_power_usage` — kWh, kW demand, power factor, CO₂, cost
- `detect_energy_anomaly` — AI anomaly detection (Isolation Forest)
- `get_energy_cost_analysis` — Electricity bill breakdown
- `forecast_energy_usage` — AI energy forecast (Prophet + XGBoost)
- `calculate_ghg_emissions` — Scope 1/2/3 GHG in tCO₂e (ISO 14064)
- `export_gri_report` — GRI 305 emissions disclosure
- `get_building_occupancy` — Per-floor occupancy data
- `predict_device_failure` — AI predictive maintenance
- `get_offline_devices` — Offline device list

## Deploy to Vercel

### Step 1 — Push to GitHub

```bash
git init
git add .
git commit -m "AsterStream MCP HTTP Server"
git remote add origin https://github.com/asterstreamtech-arch/AsterStreamTech-AIoT-mcp.git
git push -u origin main
```

### Step 2 — Set Environment Variables in Vercel Dashboard

Go to Vercel → Project → Settings → Environment Variables and add:

| Variable | Value |
|----------|-------|
| `ASTERSTREAM_API_TOKEN` | `ast_live_8vnWJXMtAmvukwFKYyZRJQCE` |
| `ASTERSTREAM_TENANT_ID` | `202554923M` |
| `TENANT_COMPANY_NAME` | `Aster Stream Tech Pte. Ltd.` |
| `TENANT_COUNTRY_CODE` | `SG` |
| `ASTERSTREAM_API_BASE` | `https://asterstreambuild.com` |

### Step 3 — Redeploy

After setting env vars, click **Redeploy** in Vercel.

### Step 4 — Submit to Smithery

MCP Server URL:
```
https://aster-stream-tech-a-io-t-mcp.vercel.app
```

## Test

```bash
# Health check
curl https://aster-stream-tech-a-io-t-mcp.vercel.app/

# MCP initialize
curl -X POST https://aster-stream-tech-a-io-t-mcp.vercel.app/mcp \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{}}}'

# List tools
curl -X POST https://aster-stream-tech-a-io-t-mcp.vercel.app/mcp \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}'
```
