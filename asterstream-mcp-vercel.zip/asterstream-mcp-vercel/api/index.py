"""
AsterStream MCP HTTP Server — Vercel Deployment
================================================
Implements MCP Streamable HTTP transport so Smithery can connect.

Endpoints:
  GET  /        → Server info (health check)
  POST /mcp     → MCP Streamable HTTP transport (main endpoint)
  GET  /sse     → SSE transport (fallback)

All tools proxy to the real AsterStream API at asterstreambuild.com.
Authentication is handled via ASTERSTREAM_API_TOKEN env var (set in Vercel).
"""
import json, os, asyncio
from datetime import datetime
from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
import httpx

app = FastAPI(title="AsterStream MCP", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Config from Vercel environment variables ──────────────────────
API_BASE    = os.getenv("ASTERSTREAM_API_BASE",  "https://asterstreambuild.com")
API_TOKEN   = os.getenv("ASTERSTREAM_API_TOKEN", "")
TENANT_ID   = os.getenv("ASTERSTREAM_TENANT_ID", "")
COMPANY     = os.getenv("TENANT_COMPANY_NAME",   "AsterStream")
COUNTRY     = os.getenv("TENANT_COUNTRY_CODE",   "SG")

# ── MCP Server metadata ───────────────────────────────────────────
SERVER_INFO = {
    "name":    "asterstream-mcp",
    "version": "1.0.0",
    "vendor":  "Aster Stream Tech Pte. Ltd.",
}

CAPABILITIES = {
    "tools": {"listChanged": False},
}

# ── Tool definitions ──────────────────────────────────────────────
TOOLS = [
    {
        "name":        "get_tenant_info",
        "description": "Return the authenticated tenant identity, company name, country, and subscription plan.",
        "inputSchema": {
            "type":       "object",
            "properties": {},
            "required":   [],
        },
    },
    {
        "name":        "get_building_power_usage",
        "description": "Get energy consumption: kWh, kW peak demand, power factor, CO₂ emissions, and electricity cost by site and period.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "period":  {"type": "string",  "enum": ["today","week","month","year"], "description": "Time period"},
                "site_id": {"type": "integer", "description": "Site ID (omit for all sites)"},
                "year":    {"type": "integer", "description": "Year (e.g. 2026)"},
                "month":   {"type": "integer", "description": "Month 1-12"},
            },
        },
    },
    {
        "name":        "detect_energy_anomaly",
        "description": "AI anomaly detection using Isolation Forest. Identifies devices consuming above their historical baseline.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "site_id":       {"type": "integer", "description": "Filter by site"},
                "threshold_pct": {"type": "number",  "description": "Deviation threshold % (default 20)"},
            },
        },
    },
    {
        "name":        "get_energy_cost_analysis",
        "description": "Detailed electricity bill: peak/off-peak kWh, demand charge, power factor penalty, total cost.",
        "inputSchema": {
            "type":       "object",
            "properties": {
                "year":    {"type": "integer", "description": "Year"},
                "month":   {"type": "integer", "description": "Month 1-12"},
                "site_id": {"type": "integer", "description": "Filter by site"},
            },
            "required": ["year", "month"],
        },
    },
    {
        "name":        "forecast_energy_usage",
        "description": "AI energy forecast for next N days using Prophet + XGBoost ensemble model.",
        "inputSchema": {
            "type":       "object",
            "properties": {
                "days":    {"type": "integer", "description": "Forecast horizon 1-30 days"},
                "site_id": {"type": "integer", "description": "Filter by site"},
            },
            "required": ["days"],
        },
    },
    {
        "name":        "calculate_ghg_emissions",
        "description": "Calculate Scope 1, 2, and 3 GHG emissions in tCO₂e. ISO 14064-1 compliant.",
        "inputSchema": {
            "type":       "object",
            "properties": {
                "start_date": {"type": "string",  "description": "ISO date YYYY-MM-DD"},
                "end_date":   {"type": "string",  "description": "ISO date YYYY-MM-DD"},
                "scope":      {"type": "string",  "enum": ["1","2","3","all"], "description": "GHG scope"},
            },
            "required": ["start_date", "end_date"],
        },
    },
    {
        "name":        "export_gri_report",
        "description": "Generate GRI 305 Emissions disclosure for the specified year.",
        "inputSchema": {
            "type":       "object",
            "properties": {
                "year": {"type": "integer", "description": "Reporting year"},
            },
            "required": ["year"],
        },
    },
    {
        "name":        "get_building_occupancy",
        "description": "Get current occupancy levels per floor and zone.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "site_id": {"type": "integer", "description": "Site ID"},
            },
        },
    },
    {
        "name":        "predict_device_failure",
        "description": "AI predictive maintenance using Isolation Forest. Returns devices with high failure probability.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "site_id":    {"type": "integer", "description": "Filter by site"},
                "days_ahead": {"type": "integer", "description": "Prediction horizon in days (default 7)"},
            },
        },
    },
    {
        "name":        "get_offline_devices",
        "description": "List devices that have gone offline in the last N hours.",
        "inputSchema": {
            "type":       "object",
            "properties": {
                "hours": {"type": "integer", "description": "Lookback window in hours (default 24)"},
            },
        },
    },
]

# ── HTTP client for AsterStream API ──────────────────────────────
def get_headers() -> dict:
    return {
        "Authorization": f"Bearer {API_TOKEN}",
        "X-Tenant-Id":   TENANT_ID,
        "Content-Type":  "application/json",
    }

async def call_api(method: str, path: str, params: dict = {}, body: dict = {}) -> dict:
    """Proxy to real AsterStream API."""
    url = f"{API_BASE}{path}"
    p   = {**params, "tenant_id": TENANT_ID}
    b   = {**body,   "tenant_id": TENANT_ID}
    async with httpx.AsyncClient(timeout=20) as client:
        if method == "GET":
            r = await client.get(url, headers=get_headers(), params=p)
        else:
            r = await client.post(url, headers=get_headers(), json=b)
    if r.status_code == 200:
        return r.json()
    return {"error": f"API returned {r.status_code}", "detail": r.text[:200]}

# ── Tool execution ────────────────────────────────────────────────
async def execute_tool(name: str, arguments: dict) -> dict:
    now = datetime.utcnow()

    if name == "get_tenant_info":
        return {
            "tenant_id":    TENANT_ID,
            "company_name": COMPANY,
            "country_code": COUNTRY,
            "api_base":     API_BASE,
            "server":       "asterstream-mcp v1.0.0",
            "timestamp":    now.isoformat() + "Z",
        }

    elif name == "get_building_power_usage":
        return await call_api("GET", "/api/energy/usage", params={
            "period":  arguments.get("period", "today"),
            "site_id": arguments.get("site_id", ""),
            "year":    arguments.get("year", now.year),
            "month":   arguments.get("month", now.month),
        })

    elif name == "detect_energy_anomaly":
        return await call_api("GET", "/api/energy/anomaly", params={
            "site_id":       arguments.get("site_id", ""),
            "threshold_pct": arguments.get("threshold_pct", 20),
        })

    elif name == "get_energy_cost_analysis":
        return await call_api("GET", "/api/energy/cost", params={
            "year":    arguments.get("year"),
            "month":   arguments.get("month"),
            "site_id": arguments.get("site_id", ""),
        })

    elif name == "forecast_energy_usage":
        return await call_api("POST", "/api/energy/forecast", body={
            "days":    arguments.get("days", 7),
            "site_id": arguments.get("site_id", ""),
        })

    elif name == "calculate_ghg_emissions":
        return await call_api("GET", "/api/esg/ghg", params={
            "start_date": arguments.get("start_date"),
            "end_date":   arguments.get("end_date"),
            "scope":      arguments.get("scope", "all"),
        })

    elif name == "export_gri_report":
        return await call_api("GET", "/api/esg/gri305", params={
            "year": arguments.get("year", now.year),
        })

    elif name == "get_building_occupancy":
        return await call_api("GET", "/api/building/occupancy", params={
            "site_id": arguments.get("site_id", ""),
        })

    elif name == "predict_device_failure":
        return await call_api("GET", "/api/building/predict-failure", params={
            "site_id":    arguments.get("site_id", ""),
            "days_ahead": arguments.get("days_ahead", 7),
        })

    elif name == "get_offline_devices":
        return await call_api("GET", "/api/building/offline", params={
            "hours": arguments.get("hours", 24),
        })

    else:
        return {"error": f"Unknown tool: {name}"}

# ── MCP message handler ───────────────────────────────────────────
async def handle_mcp_message(message: dict) -> dict:
    method = message.get("method", "")
    msg_id = message.get("id")
    params = message.get("params", {})

    # initialize
    if method == "initialize":
        return {
            "jsonrpc": "2.0",
            "id":      msg_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "capabilities":    CAPABILITIES,
                "serverInfo":      SERVER_INFO,
            },
        }

    # tools/list
    elif method == "tools/list":
        return {
            "jsonrpc": "2.0",
            "id":      msg_id,
            "result":  {"tools": TOOLS},
        }

    # tools/call
    elif method == "tools/call":
        tool_name = params.get("name", "")
        arguments = params.get("arguments", {})
        result    = await execute_tool(tool_name, arguments)
        return {
            "jsonrpc": "2.0",
            "id":      msg_id,
            "result": {
                "content": [
                    {
                        "type": "text",
                        "text": json.dumps(result, ensure_ascii=False, indent=2),
                    }
                ],
                "isError": "error" in result,
            },
        }

    # ping
    elif method == "ping":
        return {"jsonrpc": "2.0", "id": msg_id, "result": {}}

    # notifications (no response needed)
    elif method.startswith("notifications/"):
        return None

    else:
        return {
            "jsonrpc": "2.0",
            "id":      msg_id,
            "error": {
                "code":    -32601,
                "message": f"Method not found: {method}",
            },
        }

# ── Routes ────────────────────────────────────────────────────────

@app.get("/")
async def health():
    """Health check — Smithery checks this first."""
    return {
        "name":    "AsterStream MCP",
        "version": "1.0.0",
        "vendor":  "Aster Stream Tech Pte. Ltd.",
        "status":  "running",
        "transport": ["streamable-http", "sse"],
        "tools":   len(TOOLS),
        "portal":  "https://mcp.asterstreamtech.com",
    }

@app.post("/mcp")
async def mcp_streamable_http(request: Request):
    """
    MCP Streamable HTTP transport.
    Smithery sends POST requests here with JSON-RPC messages.
    """
    body = await request.body()

    try:
        data = json.loads(body)
    except Exception:
        return JSONResponse(
            {"jsonrpc": "2.0", "id": None,
             "error": {"code": -32700, "message": "Parse error"}},
            status_code=400,
        )

    # Handle batch requests
    if isinstance(data, list):
        results = []
        for msg in data:
            r = await handle_mcp_message(msg)
            if r is not None:
                results.append(r)
        return JSONResponse(results)

    # Single request
    result = await handle_mcp_message(data)
    if result is None:
        return Response(status_code=202)  # Accepted (notification)
    return JSONResponse(result)

@app.get("/sse")
async def mcp_sse(request: Request):
    """
    SSE transport fallback.
    Keeps connection open and sends MCP messages as SSE events.
    """
    async def event_stream():
        # Send endpoint info
        endpoint_url = str(request.base_url) + "messages"
        yield f"event: endpoint\ndata: {json.dumps({'uri': endpoint_url})}\n\n"
        # Keep alive
        while True:
            yield ": keepalive\n\n"
            await asyncio.sleep(15)

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control":               "no-cache",
            "Connection":                  "keep-alive",
            "Access-Control-Allow-Origin": "*",
        },
    )

@app.post("/messages")
async def mcp_sse_messages(request: Request):
    """SSE transport: receive messages via POST."""
    body = await request.body()
    try:
        data = json.loads(body)
    except Exception:
        return JSONResponse(
            {"jsonrpc": "2.0", "id": None,
             "error": {"code": -32700, "message": "Parse error"}},
            status_code=400,
        )
    result = await handle_mcp_message(data)
    if result is None:
        return Response(status_code=202)
    return JSONResponse(result)
